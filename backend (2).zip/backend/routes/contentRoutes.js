const express = require('express');
const router = express.Router();
const { getPageContent, updatePageContent, getCauseContent, getTestimonials, getPagesList } = require('../controllers/contentController');
const { protect } = require('../middleware/authMiddleware');

// Public read endpoints
router.get('/content/page/:slug', getPageContent);
router.get('/content/pages', getPagesList);
router.get('/content/cause/:slug', getCauseContent);
router.get('/testimonials', getTestimonials);

// Protected write endpoints
router.put('/content/page/:slug', protect, updatePageContent);

module.exports = router;
